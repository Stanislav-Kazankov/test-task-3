'use strict';

(function () {
  jQuery(function($) {
    $(document).ready(function(){
      $('.time-field--start').mask('00:00');
    });
  });
})();
